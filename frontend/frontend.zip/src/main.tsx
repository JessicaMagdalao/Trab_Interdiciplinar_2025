import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

import './index.css';

import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { AnimeDetails } from './pages/AnimeDetails';
import { GeneroPage } from './pages/GeneroPage';
import { Favoritos } from './pages/Favoritos';

/**
 * Componente para página não encontrada (404).
 */
function NotFound() {
  return (
    <div className="container mx-auto px-4 py-16 text-center">
      <div className="max-w-md mx-auto space-y-6">
        <h1 className="text-4xl font-bold">Página não encontrada</h1>
        <p className="text-muted-foreground">
          A página que você está procurando não existe ou foi movida.
        </p>
        <div>
          <Link
            to="/"
            className="inline-block px-6 py-3 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
          >
            Voltar ao Início
          </Link>
        </div>
      </div>
    </div>
  );
}

/**
 * Componente principal da aplicação com roteamento.
 */
function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          {/* Página inicial */}
          <Route path="/" element={<Home />} />

          {/* Detalhes do anime */}
          <Route path="/anime/:id" element={<AnimeDetails />} />

          {/* Página de gêneros */}
          <Route path="/genero" element={<GeneroPage />} />
          <Route path="/genero/:nome" element={<GeneroPage />} />

          {/* Página de favoritos */}
          <Route path="/favoritos" element={<Favoritos />} />

          {/* Página não encontrada */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Layout>
    </Router>
  );
}

// Renderiza a aplicação
const rootElement = document.getElementById('root');

if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <App />
    </StrictMode>
  );
}
