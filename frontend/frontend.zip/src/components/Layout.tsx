import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Home, Heart, Filter, Search, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

interface LayoutProps {
  children: React.ReactNode;
}

/**
 * Layout principal da aplicação.
 * Inclui header fixo, navegação (desktop/mobile) e footer informativo.
 */
export function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  /** Verifica se rota está ativa para estilização */
  const isActiveRoute = (path: string): boolean => {
    return path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);
  };

  /** Itens de navegação principais */
  const navigationItems = [
    { label: 'Início', path: '/', icon: Home },
    { label: 'Favoritos', path: '/favoritos', icon: Heart },
    { label: 'Gêneros', path: '/genero', icon: Filter }
  ];

  /** Renderiza item do menu */
  const renderNavItem = (item: (typeof navigationItems)[0], mobile = false) => {
    const Icon = item.icon;
    const isActive = isActiveRoute(item.path);
    return (
      <Link
        key={item.path}
        to={item.path}
        className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
          mobile ? 'w-full justify-start' : ''
        } ${isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-muted'}`}
        onClick={() => mobile && setMobileMenuOpen(false)}
      >
        <Icon className="h-4 w-4" />
        <span>{item.label}</span>
      </Link>
    );
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <Link
              to="/"
              className="flex items-center gap-2 font-bold text-xl hover:text-primary transition-colors"
            >
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-primary-foreground font-bold">
                A
              </div>
              <span>YumeGate Animes</span>
            </Link>

            {/* Navegação Desktop */}
            <nav className="hidden md:flex items-center gap-2">
              {navigationItems.map(item => renderNavItem(item))}
            </nav>

            {/* Botão de busca rápida */}
            <div className="hidden md:flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/')}
                className="flex items-center gap-2"
              >
                <Search className="h-4 w-4" />
                Pesquisar
              </Button>
            </div>

            {/* Menu Mobile */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="md:hidden"
                  aria-label="Abrir menu de navegação"
                >
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64">
                <div className="flex flex-col gap-4 mt-8">
                  {/* Logo menu mobile */}
                  <div className="flex items-center gap-2 font-bold text-lg pb-4 border-b">
                    <div className="w-6 h-6 bg-primary rounded flex items-center justify-center text-primary-foreground text-sm font-bold">
                      A
                    </div>
                    <span>Anime App</span>
                  </div>

                  {/* Itens menu mobile */}
                  <nav className="flex flex-col gap-2">
                    {navigationItems.map(item => renderNavItem(item, true))}
                  </nav>

                  {/* Busca mobile */}
                  <Button
                    variant="outline"
                    onClick={() => {
                      navigate('/');
                      setMobileMenuOpen(false);
                    }}
                    className="flex items-center gap-2 justify-start w-full"
                  >
                    <Search className="h-4 w-4" />
                    Pesquisar Animes
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      {/* Conteúdo */}
      <main className="flex-1">{children}</main>

      {/* Footer */}
      <footer className="border-t bg-muted/50">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-3">
              <h3 className="font-semibold">Anime App</h3>
              <p className="text-sm text-muted-foreground">
                Descubra, explore e favorite seus animes preferidos. Plataforma completa para fãs de anime.
              </p>
            </div>
            <div className="space-y-3">
              <h3 className="font-semibold">Navegação</h3>
              <div className="flex flex-col gap-2">
                {navigationItems.map(item => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {item.label}
                  </Link>
                ))}
              </div>
            </div>
            <div className="space-y-3">
              <h3 className="font-semibold">Recursos</h3>
              <div className="flex flex-col gap-2 text-sm text-muted-foreground">
                <span>Pesquisa Avançada</span>
                <span>Lista de Favoritos</span>
                <span>Filtros por Gênero</span>
                <span>Estatísticas Pessoais</span>
              </div>
            </div>
            <div className="space-y-3">
              <h3 className="font-semibold">Informações</h3>
              <div className="flex flex-col gap-2 text-sm text-muted-foreground">
                <span>Dados da AniList API</span>
                <span>Atualizado Diariamente</span>
                <span>Interface Responsiva</span>
                <span>Código Aberto</span>
              </div>
            </div>
          </div>

          <div className="border-t mt-8 pt-6 text-center">
            <p className="text-sm text-muted-foreground">
              © 2024 Anime App. Desenvolvido para a comunidade anime.
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Dados fornecidos pela AniList API
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

/** Breadcrumb */
interface BreadcrumbProps {
  items: Array<{ label: string; path?: string }>;
}

export function Breadcrumb({ items }: BreadcrumbProps) {
  return (
    <nav
      aria-label="Breadcrumb"
      className="flex items-center space-x-2 text-sm text-muted-foreground mb-6"
    >
      <Link to="/" className="hover:text-foreground transition-colors">
        Início
      </Link>
      {items.map((item, index) => (
        <React.Fragment key={index}>
          <span>/</span>
          {item.path ? (
            <Link to={item.path} className="hover:text-foreground transition-colors">
              {item.label}
            </Link>
          ) : (
            <span className="text-foreground font-medium">{item.label}</span>
          )}
        </React.Fragment>
      ))}
    </nav>
  );
}
